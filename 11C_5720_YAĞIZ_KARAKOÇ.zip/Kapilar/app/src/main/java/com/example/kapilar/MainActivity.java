package com.example.kapilar; // BURAYI KENDİ EKRANINDAKİYLE AYNI YAP (SİLME)

import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Nesne Tanımlamaları
    Switch s1, s2;
    Button bAnd, bOr, bNand, bNor, bNot;
    TextView sonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        s1 = findViewById(R.id.sw1);
        s2 = findViewById(R.id.sw2);
        sonuc = findViewById(R.id.tvSonuc);

        bAnd = findViewById(R.id.btnAND);
        bOr = findViewById(R.id.btnOR);
        bNand = findViewById(R.id.btnNAND);
        bNor = findViewById(R.id.btnNOR);
        bNot = findViewById(R.id.btnNOT);

        // AND (VE)
        bAnd.setOnClickListener(v -> {
            if (s1.isChecked() && s2.isChecked()) sonuc.setText("Sonuç: 1");
            else sonuc.setText("Sonuç: 0");
        });

        // OR (VEYA)
        bOr.setOnClickListener(v -> {
            if (s1.isChecked() || s2.isChecked()) sonuc.setText("Sonuç: 1");
            else sonuc.setText("Sonuç: 0");
        });

        // NAND (VE DEĞİL)
        bNand.setOnClickListener(v -> {
            if (!(s1.isChecked() && s2.isChecked())) sonuc.setText("Sonuç: 1");
            else sonuc.setText("Sonuç: 0");
        });

        // NOR (VEYA DEĞİL)
        bNor.setOnClickListener(v -> {
            if (!(s1.isChecked() || s2.isChecked())) sonuc.setText("Sonuç: 1");
            else sonuc.setText("Sonuç: 0");
        });

        // NOT (DEĞİL)
        bNot.setOnClickListener(v -> {
            if (!s1.isChecked()) sonuc.setText("Sonuç: 1");
            else sonuc.setText("Sonuç: 0");
        });
    }
}